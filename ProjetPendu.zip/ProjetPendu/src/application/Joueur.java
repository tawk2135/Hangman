package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Scanner;

public class Joueur {
	private String Nom;
	private int Score;
	//Declaration des proprietes
	private ArrayList<Joueur> Listejoueur;
	public ArrayList<Joueur> getJoueur() {
		return Listejoueur;
	}

	public void setJoueur(ArrayList<Joueur> joueur) {
		this.Listejoueur = joueur;
	}

	public String getNom() {
		return Nom;
	}

	public void setNom(String nom) {
		Nom = nom;
	}

	public int getScore() {
		return Score;
	}

	public void setScore(int score) {
		Score = score;
	}

	public Joueur(String nom, int score)
	{
		nom=Nom;
		score=Score;
	}

	public Joueur()
	{
		
	}
	public void findScore(String nom) throws FileNotFoundException
	{
		
		}
//	static String filename="listejoueur.txt";
//	String line;
//	String [] joueur1;
	
//	public Joueur() throws Exception
//	{
//		joueur=new ArrayList<Joueur>();
//		 File file = new File(filename);
//		 try {
//		      FileWriter myWriter = new FileWriter("listejoueur.txt");
//		      
//		      myWriter.close();
//		      System.out.println("Successfully wrote to the file.");
//		    } catch (IOException e) {
//		      System.out.println("An error occurred.");
//		      e.printStackTrace();
//		    }
//	
//	}

}
