package application;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.TimerTask;

import javax.swing.JButton;

import com.sun.glass.ui.Timer;

import javafx.animation.AnimationTimer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class SampleController implements Initializable {
	// Declaration des proprieters
	Joueur joueur;
	listeJoueurs Liste;
	alertbox alert;
	private String randomWord = "";// mot a decouvrir
	private char[] hidden;
	Button bouton = new Button();
	private ArrayList<String> lettres = new ArrayList<>();
	public static final String Nomfich = "Mots.txt";
	Scanner read = new Scanner(System.in);
	public static final int chance = 6;// nbre d'erreurs allouer
	private int erreur = 0;// lettre deja entrer
	boolean mottrouver;
	boolean gameStart = true;
	String nom;
	int Score = 0;

	@FXML
	private BorderPane bigWindow;
	
	@FXML
	private Pane mainWindow;

	@FXML
	private Canvas hangman;

	@FXML
	private Ellipse face;

	@FXML
	private Line body;

	@FXML
	private Line arm1;

	@FXML
	private Line arm2;

	@FXML
	private Line leg1;

	@FXML
	private Line leg2;

	@FXML
	private Button A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;

	

	@FXML
	private Button btnvalidate;

	@FXML
	private Button btnstart;

	@FXML
	private TextField txtNom;

	@FXML
	private TextField txtlettre;

	@FXML
	private TextField txtMot;

	@FXML
	private Label lblnom;

	@FXML
	private Label score;

	@FXML
	private Label lblpointage;

	@FXML
	private Button btnQuitter;

	@FXML
	private MenuBar Menu1;

	@FXML
	private Menu Menus;

	@FXML
	private MenuItem menuQuitter;

	@FXML
	private MenuItem HowToPlay;

	@FXML
	private Button btnAstuce;

	@FXML
	void ValidationAstuce(ActionEvent event) {
		int p;
		char answer=' ';
		boolean verif=true;
		while (verif) {
			Random f = new Random();
			for (int i = 0; i < randomWord.length(); i++) {
				answer = randomWord.charAt(f.nextInt(randomWord.length()));

			}
			int index = txtMot.getText().indexOf(answer);
			if (index==-1) {
				verif=false;
			}
		}
		alertbox.display("Astuce", "Avez-vous essayer la lettre:"+" "+ answer);
		
	}

	// Les instructions
	@FXML
	void Instruction(ActionEvent event) {
		alertbox.display("Instruction",
				"Voici les Instructions du jeu \n 1 - En premier lieu vous devez inscrire votre nom dans le champs Nom:\n "
						+ "2-Cliquer sur 'DEBUTER PARTIE' deviner toute les lettres du mot \n 3- Apres chaque lettre cliquez vous devez cliquer sur VALIDER LETTRE \n"
						+ "4- Chaque bonne lettre vous donne 1 point \n 5-Chaque mauvaise lettre vous donne un partie du corps du bonhomme pendu\n 6-Pour gagner vous devez avoir "
						+ "toute les lettres correctes BONNE CHANCE!");
	}

	// Methode lorsque la lettre est cliquer
	@FXML
	void Lettrecliquer(ActionEvent event) {
		Button but = (Button) event.getSource();
		txtlettre.setText(but.getText());
		but.setDisable(true);
	}

	// Methode du bouton debuter la partie
	@FXML
	void debuterPartie(ActionEvent event) throws IOException {
		//Liberer les boutons
		ReinitialiserBout();
		while (gameStart) {
			try {
				nom = txtNom.getText();
//Si le nom est vide lancer une exception
				if (nom.isEmpty() || nom == null) {
					throw new NullPointerException();

				} else {
					alertbox.display("Message", "Bonne Chance" + " " + nom);
					gameStart = false;
					face.setVisible(false);
					arm1.setVisible(false);
					arm2.setVisible(false);
					leg1.setVisible(false);
					leg2.setVisible(false);
					body.setVisible(false);
					lblnom.setText(nom);
					txtNom.setDisable(true);
					txtlettre.setDisable(false);
					btnstart.setDisable(true);

					findword();

					break;
				}
			} catch (NullPointerException exc) {
				alertbox.display("Erreur", "Vous devez entrer un nom avant de debuter la partie");
				break;
			}
		}
	}

	// Methode pour fermer le programme
	@FXML
	void fermerProgram(ActionEvent event) {
		alertbox.display("Au revoir", "Merci d'avoir joué");
		// get a handle to the stage
		Stage stage = (Stage) btnQuitter.getScene().getWindow();
		// do what you have to do
		stage.close();
	}

	// Initialisation de lenghtException
	public class lenghtException extends Exception {

	}

	// Acceptation de la lettre
	@FXML
	void validerLettre(ActionEvent event) throws Exception {
		String c = txtlettre.getText().toUpperCase();
		listeJoueurs Liste = new listeJoueurs();
		Joueur joueur = new Joueur();

		try {
			
			if (c.length() == 0 || c.length() > 1)
				throw new lenghtException();
			else {
				//Si la lettre valider est dans le mot rechercher
				if (randomWord.contains(c)) {
					//Ajouter la lettre a la collection
					lettres.add(c);
					//Aviser le joueur que la lettre est existante ds le mot
					alertbox.display("Message", "Bravo il y a un " + " " + c);
					//Allouer les points
					aumenterPoints();
//Creation du StringBuilder 
					StringBuilder word = new StringBuilder(txtMot.getText());
					//identification de la position de la lettre rechercher
					int i = randomWord.indexOf(c);
					//Implementation du char
					char f = c.charAt(0);
					//Remplacement du '-' par la lettre
					word.setCharAt(i, f);
					txtMot.setText(word.toString());
					//conversion de int en String

					String pointage = String.valueOf(Score);
					//Emettre le pointage dans les textfield score
					score.setText(pointage);
					//Vider le txtfield de la lettre a valider
					txtlettre.clear();
					// Recommencer la partie
					if (txtMot.getText().equals(randomWord)) {
						//Message avisant la partie fini et gagner
						alertbox.display("Bravo!", "Vous avez gagne");
						//Ajout de 5 points lorsque la partie est terminer
						Score = Score + 5;
						//Ajouter le nom joueur dans la collection
						joueur.setNom(nom);
						//Ajouter le score dans la collection
						joueur.setScore(Score);
						// Ajouter dans la collection
						Liste.ajouterJoueur(joueur);
						// Ajouter dans un fichier texte
						Liste.addPlayer(nom, Score);
						alertbox.display("Avertissement", "Nouvelle Partie veuillez peser sur 'debuter ...'");
						initialize(null, null);
						
						lettres.clear();
					}
				} else {
					augmenterErreur();
					lettres.add(c);
					switch (erreur) {
					case 1:
						face.setVisible(true);
						break;
					case 2:
						body.setVisible(true);
						break;
					case 3:
						arm1.setVisible(true);
						break;
					case 4:
						arm2.setVisible(true);
						break;
					case 5:
						leg1.setVisible(true);
						break;
					case 6:
						leg2.setVisible(true);
						alertbox.display("Avertissement", "Vous avez perdu");
						// Ajouter la proprieter du nom au joueur
						joueur.setNom(nom);
						joueur.setScore(Score);
						// Ajouter dans la collection
						Liste.ajouterJoueur(joueur);
						// Ajouter dans un fichier texte
						Liste.addPlayer(nom, Score);
						initialize(null, null);
						gameStart = true;
						//Mettre le pointage
						lblpointage.setText(score.getText());
						//Enlever le mot
						txtMot.clear();
						//Enlever la lettre du champs
						txtlettre.clear();
						
						initialize(null, null);
						break;

					}
				}
			}

		} catch (lenghtException e) {
			// TODO Auto-generated catch block
			alertbox.display("Avertissement", "Vous devez rentrer une seule lettre");
		}
	}

	private void ReinitialiserBout() {
		// Remettre les boutons disponible
		A.setDisable(false);B.setDisable(false);C.setDisable(false);D.setDisable(false);E.setDisable(false);
		G.setDisable(false);H.setDisable(false);I.setDisable(false);J.setDisable(false);F.setDisable(false);
		K.setDisable(false);L.setDisable(false);M.setDisable(false);N.setDisable(false);O.setDisable(false);
		P.setDisable(false);Q.setDisable(false);R.setDisable(false);S.setDisable(false);T.setDisable(false);
		U.setDisable(false);V.setDisable(false);W.setDisable(false);X.setDisable(false);Y.setDisable(false);
		Z.setDisable(false);
		
	}

	public void aumenterPoints() {
		++Score;
	}

	public void augmenterErreur() {
		erreur = erreur + 1;
	}

	public void findword() throws IOException {

		try {
			//Creer un bufferedreader
			BufferedReader reader = new BufferedReader(new FileReader(Nomfich));
			String s1 = "";
			String line = reader.readLine();
			//Creer une collection de mot a partir du fichier text
			ArrayList<String> words = new ArrayList<String>();
			while (line != null) {
				String[] wordsLine = line.split(" ");
				for (String word : wordsLine) {
					words.add(word);
				}
				line = reader.readLine();
			}

			Random rand = new Random(System.currentTimeMillis());
			randomWord = words.get(rand.nextInt(words.size()));
			char[] randomwordtoguess = randomWord.toCharArray();
			char[] hidden = randomwordtoguess.clone();

			for (int i = 0; i < hidden.length; i++) {
				hidden[i] = '-';
			}

			s1 = new String(randomwordtoguess);
			String s2 = new String(hidden);
			System.out.println(s1);
			txtMot.setText(s2);
			// txtMot.setText(randomWord);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		GraphicsContext gc = hangman.getGraphicsContext2D();
		txtMot.setDisable(true);
		txtlettre.setDisable(true);
		btnstart.setDisable(false);
		gameStart = true;
		erreur = 0;
		int scorefinal = Integer.parseInt(lblpointage.getText()) + Score;
		lblpointage.setText(Integer.toString(scorefinal));
		//Reinitialiser le score
		score.setText("0");
		Score = 0;

	}

}
