package application;

import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.*;
import javafx.scene.layout.VBox;
import javafx.scene.control.*;
import javafx.geometry.*;

public class alertbox {
	public static void display(String title, String message) {
		Stage alert1 = new Stage();
		alert1.initModality(Modality.APPLICATION_MODAL);
		alert1.setTitle(title);
		alert1.setMinWidth(500);
		alert1.setMinWidth(500);
		Label label=new Label();
		label.setText(message);
		Button closeButton=new Button("OK");
		
		closeButton.setOnAction(e->alert1.close());
		VBox layout=new VBox(10);
		layout.getChildren().addAll(label,closeButton);
		layout.setAlignment(Pos.CENTER);
		Scene scene=new Scene(layout);
		alert1.setScene(scene);
		alert1.showAndWait();
	}
}
