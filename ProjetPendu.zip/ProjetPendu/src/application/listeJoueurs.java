package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.stream.Stream;

public class listeJoueurs {
	public ArrayList<Joueur> joueur = new ArrayList<Joueur>();

	public ArrayList<Joueur> getJoueur() {
		return joueur;

	}

	public void setJoueur(ArrayList<Joueur> joueur) {
		this.joueur = joueur;

	}

	public void ajouterJoueur(Joueur j) {
		int f = 0;
		joueur.add(j);

	}

	public void addPlayer(String nom, int score) {
		try {
			FileWriter writer = new FileWriter("listejoueur.txt", true);
			writer.write("\n" + nom + "," + score);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	public listeJoueurs()
	{
		
		BufferedReader in = null;
		try {
		    in = new BufferedReader(new FileReader("listejoueur.txt"));
		    String read = null;
		    String[] splited;
		    while ((read = in.readLine()) != null) {
		       	splited = read.split(",");
		        	joueur.add(new Joueur(splited[0],Integer.parseInt(splited[1]))); 
		    }
		} catch (IOException e) {
		   alertbox.display("Avertissement", "Fichier introuvable ");
		    e.printStackTrace();
		} finally {
		    try {
		        in.close();
		    } catch (Exception e) {
		    
		    }
		}
	}
}
